SPRINGBOOT, THYMELEAF, JAVA, JAVASCRIPT 
Duomenų bazė: MariaDB
Projektas „LTB Financial Solutions“
Darbą atliko: Tautvydas Šepetys

Projekto informacija:
Naudojantis svetaine, jūs galite įrašyti savo gautas pajamas / išlaidas, peržiūrėti įrašytas pajamas / išlaidas,
redaguoti ir ištrinti.
Java direktorijoj galite rasti viską ko jums reikės iš User klasės, kontrolerį.


@CodeAcademy.lt atsiskaitomajam darbui
